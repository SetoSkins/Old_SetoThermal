#!/system/bin/sh
sleep 5

am kill logd
killall -9 logd

am kill logd.rc
killall -9 logd.rc

am kill mobile_log_d
killall -9 mobile_log_d
am kill mobile_log_d.rc
killall -9 mobile_log_d.rc

grep_prop() {
    local REGEX="s/^$1=//p"
    shift
    local FILES="$@"
    [[ -z "$FILES" ]] && FILES='/system/build.prop'
    sed -n "$REGEX" ${FILES} 2>/dev/null | head -n 1
}
MODDIR=${0%/*}
LSPMISC_PATH=$(cat /data/adb/lspd/misc_path)
LSPBASE_PATH="/data/misc/$LSPMISC_PATH"
LSPLOG_PATH="${LSPBASE_PATH}/log"
LSP_NEW_LOG_PATH="/data/adb/lspd/log/"

        
a=1
   while true
    do
sleep 3
mkdir -p ${LSPLOG_PATH}
rm "${LSPLOG_PATH}/modules.log" 
rm "${LSPLOG_PATH}/all.log" 
mkdir -p ${LSP_NEW-LOG_PATH}
rm "${LSP_NEW_LOG_PATH}/modules.log" 
rm "${LSP_NEW_LOG_PATH}/all.log" 
rm "${LOG_PATH}/modules.log" 
a=$(($a+1))
echo $a
     if [[ $a>3 ]]; then
            break
        fi
done